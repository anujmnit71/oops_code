package poker;

public enum Suit {Hearts, Diamonds, Spades, Clubs}