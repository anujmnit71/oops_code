This is a fully functional poker (Holdem or Omaha) game which can be played over a network, supports up to 9 players, 
and comes complete with a graphical user interface and chat. If testing over a network, one will have to enter the IP 
of the machine running the server (and enable port-forwarding). The server must be running before any clients can connect. 
At least two clients must join a table before a game can begin. Happy gaming.